package com.example.eco;

import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eco.Model.CategoryModel;
import com.example.eco.Model.CustomerModel;
import com.example.eco.Model.ProductModel;

import java.nio.BufferUnderflowException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class MyDatabaseClass extends SQLiteOpenHelper {
    public static String DBName = "MyECOdatabase";
    public static SQLiteDatabase MyDataBase;

    public MyDatabaseClass() {
        super(null, DBName, null, 5);
    }

    public MyDatabaseClass(Context context) {
        super(context, DBName, null, 5);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table Customers(CustID integer primary key autoincrement,Username text not null,Password text not null,Gender text not null,Birthdate text,Job text,Image blob,Email text unique)");
        sqLiteDatabase.execSQL("create table Category (CatID integer primary key  autoincrement , CatName text unique not null )");
        sqLiteDatabase.execSQL("create table Orders (OrdID integer  primary key autoincrement, OrdDate text not null,Cust_ID integer not null,Address text not null ,Confirmed INTEGER DEFAULT 0,foreign key(Cust_ID) references Customers(CustID))");
        sqLiteDatabase.execSQL("create table Products (ProID integer primary key autoincrement, ProName text not null ," + "price real not null ,ProImage blob, quantity integer not null ,barcode blob, Cat_ID integer not null ," + "foreign key (Cat_ID)references Category (CatID))"); //Aw CatID
        sqLiteDatabase.execSQL("create table OrderDetails (Ord_ID integer primary key autoincrement  , Pro_ID integer not null ,Quantity integer not null ,foreign key (Ord_ID) references Orders(OrdID) ,foreign key(Pro_ID)references Products(ProID) );");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists Customers");
        db.execSQL("drop table if exists Category");
        db.execSQL("drop table if exists Products");
        db.execSQL("drop table if exists Orders");
        db.execSQL("drop table if exists OrderDetails");
        onCreate(db);
    }

    public void First() {
        CustomerModel m = new CustomerModel();
        m.setCustBirthDate("24102020");
        m.setCustJop("SWE");
        m.setCustName("Kelly");
        m.setGender("Male");
        m.setPassword("Kelly");
        AddCustomer(m);
    }

    public void AddCustomer(CustomerModel cust) {
        MyDataBase = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("Username", cust.getCustName());
        values.put("Password", cust.getPassword());
        values.put("Birthdate", cust.getCustBirthDate());
        values.put("Gender", cust.getGender());
        values.put("Job", cust.getCustJop());
        values.put("Image", cust.getImg());
        values.put("Email", cust.getEmail());

        MyDataBase.insert("Customers", null, values);
        MyDataBase.close();

    }
    public void AddOrder(String Email,String ProID,int Quantity,String Address) {



        MyDataBase = getWritableDatabase();
        ContentValues values = new ContentValues();
       String Cust_ID= GetCustID(Email);
        String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

        values.put("Pro_ID", ProID);

        values.put("Quantity", Quantity);

        MyDataBase = getWritableDatabase();

        //MyDataBase.insert("OrderDetails", null, values);
        /*int id = (int) MyDataBase.insertWithOnConflict("OrderDetails", null, values, SQLiteDatabase.CONFLICT_IGNORE);
        if (id == -1) {

            MyDataBase.update("OrderDetails", values, "Pro_ID=?", new String[] {ProID});  // number 1 is the _id here, update to variable for your code
        }*/
        MyDataBase.insert("OrderDetails",  "Pro_ID=?",values);  // number 1 is the _id here, update to variable for your code

        MyDataBase.close();
        MyDataBase = getReadableDatabase();
        String[] arg={Cust_ID};
        String Ord_ID = null;
        Cursor cursor = MyDataBase.rawQuery("select OrdID from Orders where Cust_ID=?", arg);
        if (cursor.getCount()>0) {

            cursor.moveToFirst();

            Ord_ID= cursor.getString(0);
        }


        MyDataBase = getWritableDatabase();
         values = new ContentValues();
        values.put("OrdDate",date);
        values.put("Cust_ID",Cust_ID);
        values.put("Address",Address);

        MyDataBase.insert("Orders", null, values);

        MyDataBase.close();
//        Toast.makeText(null," Wslt",Toast.LENGTH_SHORT).show();

    }
public HashMap<String,String> GetConfirmedOrders(String Email)
{
    //return OrdDate,Count of this date
    HashMap<String,String> ConfirmedOrders= new HashMap<>();


    String Cust_ID=GetCustID(Email);


    MyDataBase = getReadableDatabase();


    Cursor c = MyDataBase.rawQuery("select OrdDate from Orders where Cust_ID='"+Cust_ID+"' and Confirmed ='"+"1'", new String[]{});

    if (c != null) {
        c.moveToFirst();

        while (!c.isAfterLast()) {
            String OrdDate=c.getString(0);
            if(ConfirmedOrders.containsKey(OrdDate))
            {
                int val=Integer.parseInt(ConfirmedOrders.get(OrdDate));
                val++;
                ConfirmedOrders.put(OrdDate,String.valueOf(val));
            }
            else
            {
                ConfirmedOrders.put(OrdDate,"1");
            }

            c.moveToNext();
        }

    }
    return ConfirmedOrders;



}
public void ConfirmOrder(String Email,String Address) {
    HashMap<String, String> Orders = GetOrders(GetCustID(Email), Email);
    for (Map.Entry me : Orders.entrySet()) {

        int ProCount=GetProductQuantity(me.getKey().toString());
        ProCount-=Integer.valueOf(me.getValue().toString());
        if(ProCount==0)//delete from database
        {

            MyDataBase=getWritableDatabase();

            MyDataBase.delete("Products", "ProName = ?", new String[]{me.getKey().toString()});


        }
        else
        {
            ContentValues values=new ContentValues();
            values.put("quantity",String.valueOf(ProCount));
            MyDataBase=getWritableDatabase();
            MyDataBase.update("Products",values,"ProName = ?",new String[]{me.getKey().toString()});

        }

    }



String Cust_ID=GetCustID(Email);
        MyDataBase = getWritableDatabase();
        ContentValues values;
         values = new ContentValues();
        values.put("Confirmed",1);
        values.put("Address",Address);

        MyDataBase.update("Orders",values,"Cust_ID = ?",new String[]{Cust_ID});
        MyDataBase.close();

       // GetOrderIDbyCustomer(Email);




    }

    public ArrayList<Bitmap> GetAllProductsImages() {
        ArrayList<Bitmap> bitmaps = new ArrayList<Bitmap>();
        MyDataBase = getReadableDatabase();

        Cursor c = MyDataBase.rawQuery("select * from Products ", null);

        if (c != null) {
            c.moveToFirst();

            while (!c.isAfterLast()) {
                byte[] blob = c.getBlob(3);
                bitmaps.add(BitmapFactory.decodeByteArray(blob, 0, blob.length));
                c.moveToNext();
            }


        }
        return bitmaps;
    }
    public ArrayList<Bitmap> GetAllProductsImages(String catName) {
        ArrayList<Bitmap> bitmaps = new ArrayList<Bitmap>();
        String catID=GetCatID(catName);
        MyDataBase = getReadableDatabase();
        Cursor c = MyDataBase.rawQuery("select * from Products where Cat_ID=?", new String[]{catID});

        if (c != null) {
            c.moveToFirst();

            while (!c.isAfterLast()) {
                byte[] blob = c.getBlob(3);
                bitmaps.add(BitmapFactory.decodeByteArray(blob, 0, blob.length));
                c.moveToNext();
            }


        }
        return bitmaps;
    }

    public ArrayList<Bitmap> GetAllProductsImagesThatContain(String partName) {
        ArrayList<Bitmap> bitmaps = new ArrayList<Bitmap>();
        MyDataBase = getReadableDatabase();
        Cursor c = MyDataBase.rawQuery("select  * from Products where ProName Like '%"+partName+"%'",new String[]{});

        if (c != null) {
            c.moveToFirst();

            while (!c.isAfterLast()) {
                byte[] blob = c.getBlob(3);
                bitmaps.add(BitmapFactory.decodeByteArray(blob, 0, blob.length));
                c.moveToNext();
            }


        }
        return bitmaps;
    }
    public void RemoveProductsFromDatabase(HashMap<String, String> Orders)
    {

        for (Map.Entry me : Orders.entrySet())
            {

            String ProName=GetProductName(me.getKey().toString());
            SetProductQuantity(ProName);
            RemoveOrder(ProName);
            //Remove order
        }

    }
    public void RemoveOrder(String ProName)
    {
        String ID=GetProID(ProName);

        //int quanity=GetProductQuantity(GetProductName(String.valueOf(ID)));
        MyDataBase=getWritableDatabase();
        MyDataBase.delete("OrderDetails", "Pro_ID = ?", new String[]{String.valueOf(ID)});

    }
    public void SetProductQuantity(String Name)
    {
        String ID=GetProID(Name);


        int quantity=GetProductQuantity(Name);
        quantity--;
        if (quantity!=0)
        {
            MyDataBase=getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("quantity",quantity); //These Fields should be your String values of actual column names
            MyDataBase.update("Products", cv, "ProID = ?", new String[]{ID});


        }
        else
        {
            //Delete
            MyDataBase=getWritableDatabase();
            MyDataBase.delete("Products", "ProID = ?", new String[]{ID});

        }

    }
    public void SetProductQuantityAtOrder(String ProName,int Quantity)
    {
        String ID=GetProID(ProName);




        if (Quantity!=0)
        {
            MyDataBase=getWritableDatabase();
            ContentValues cv = new ContentValues();
            cv.put("quantity",Quantity); //These Fields should be your String values of actual column names
            MyDataBase.update("OrderDetails", cv, "Pro_ID = ?", new String[]{ID});


        }


    }
    public int GetProductQuantity(String Name)
    {
        String ID=GetProID(Name);
        MyDataBase=getReadableDatabase();
        String []arg={ID};
        Cursor c = null;
        try {
            c= MyDataBase.rawQuery("select quantity from Products where ProID=?", arg);

        if (c != null) {
            c.moveToFirst();

            if (c.getCount()>0) {
                return c.getInt(0);

            }


        }
        } finally {
            c.close();

        }
        return -1;
    }
    String GetOrderIDbyCustomer(String Email)
    {
        String ID=GetCustID(Email);
        MyDataBase=getReadableDatabase();
        String[]args={ID,"0"};
        Cursor cursor=MyDataBase.rawQuery("select OrdID from Orders where Cust_ID =? and Confirmed=?",args);

        if (cursor.getCount()>0) {

            cursor.moveToFirst();
            MyDataBase.close();
            return cursor.getString(0);
        }
        MyDataBase.close();

        cursor.close();
        return null;


    }
    public int GetProductQuantityFromOrder(String ProName,String Email)
    {
        String OrdID=GetOrderIDbyCustomer(Email);

        String []arg={OrdID,ProName};
        if(OrdID==null)
        {
            return 0;
        }

        String ID=GetProID(ProName);
        MyDataBase=getReadableDatabase();

        Cursor c = null; 
            try {
        c= MyDataBase.rawQuery("select Quantity from OrderDetails where Ord_ID='"+OrdID+"' and Pro_ID = '"+ID+"'", new String[]{});

        if (c != null) {


                c.moveToFirst();

                if (c.getCount() > 0) {
                    return c.getInt(0);

                }



        }}
         finally {
                    c.close();

                }
        return 0;
        /*String ID=GetProID(ProName);
        MyDataBase=getReadableDatabase();
        String []arg={ID};
        Cursor c = MyDataBase.rawQuery("select Quantity from OrderDetails where Pro_ID=?", arg);

        if (c != null) {
            c.moveToFirst();

            if (c.getCount()>0) {
                return c.getInt(0);

            }


        }
        return 0;*/
    }
    public Bitmap getProdImageByProdID(String ProID)
    {
        Bitmap bitmaps = null;
        MyDataBase = getReadableDatabase();
        String []arg={ProID};
        Cursor c = null;
        try {
            c = MyDataBase.rawQuery("select ProImage from Products where ProID=?", arg);

            if (c != null) {
                c.moveToFirst();

                if (c.getCount() > 0) {
                    byte[] blob = c.getBlob(0);
                    bitmaps = BitmapFactory.decodeByteArray(blob, 0, blob.length);
                    c.moveToNext();
                }


            }
        }finally {
            c.close();
        }
        return bitmaps;

    }
public String GetProductName(String ID)
{
    MyDataBase=getReadableDatabase();
    String []arg={ID};
    Cursor c = MyDataBase.rawQuery("select ProName from Products where ProID=?", arg);

    if (c != null) {
        c.moveToFirst();

        if (c.getCount()>0) {
             return c.getString(0);

        }


    }
    return "NotFound";

}
public String GetProductPrice(String ID)
{
    MyDataBase=getReadableDatabase();
    String []arg={ID};
    Cursor c = MyDataBase.rawQuery("select price from Products where ProID=?", arg);

    if (c != null) {
        c.moveToFirst();

        if (c.getCount()>0) {
             return c.getString(0);

        }


    }
    return "NotFound";

}
   public ArrayList<String> GetProducts()
    {

        MyDataBase=getReadableDatabase();
        ArrayList<String>arr=new ArrayList<String>();
        Cursor c=MyDataBase.rawQuery("select * from Products ",null);

        if (c != null) {
            c.moveToFirst();

            while (!c.isAfterLast()) {
             //   String blob = c.getString(1); //1 2 4
                arr.add(c.getString(1));
                arr.add(c.getString(2));
                arr.add(c.getString(4));
                c.moveToNext();
            }


        }
        MyDataBase.close();

        c.close();
        return arr;
    }
 public ArrayList<String> GetProducts(String catName)
    {

        ArrayList<String>arr=new ArrayList<String>();
        String catID=GetCatID(catName);
        MyDataBase=getReadableDatabase();
        Cursor c=MyDataBase.rawQuery("select * from Products where Cat_ID=?",new String[]{catID});

        if (c != null) {
            c.moveToFirst();

            while (!c.isAfterLast()) {
             //   String blob = c.getString(1); //1 2 4
                arr.add(c.getString(1));
                arr.add(c.getString(2));
                arr.add(c.getString(4));
                c.moveToNext();
            }


        }
        MyDataBase.close();

        c.close();
        return arr;
    }


 public ArrayList<String> GetProductsthatContains(String partName)
    {

        ArrayList<String>arr=new ArrayList<String>();

        MyDataBase=getReadableDatabase();
        Cursor c=MyDataBase.rawQuery("select distinct  * from Products where ProName Like ?",new String[]{partName});
      c=  MyDataBase.rawQuery("select  * from Products where ProName LIKE \'%"+partName+"%\'", new String[]{});

        if (c != null) {
            c.moveToFirst();

            while (!c.isAfterLast()) {
             //   String blob = c.getString(1); //1 2 4
                arr.add(c.getString(1));
                arr.add(c.getString(2));
                arr.add(c.getString(4));
                c.moveToNext();
            }


        }
        MyDataBase.close();

        c.close();
        return arr;
    }


    public HashMap<String, String> GetOrders(String ID,String Email)
    {
        ArrayList<String>OrderIDs=new ArrayList<String>();
        MyDataBase = getReadableDatabase();
        String[] arg={ID,"0"};

        Cursor c = MyDataBase.rawQuery("select * from Orders where Cust_ID=? and Confirmed=?", arg);

        if (c != null) {
            c.moveToFirst();

            while (!c.isAfterLast()) {

                OrderIDs.add(c.getString(0));

                c.moveToNext();
            }


        }

        //Kda gbt elOrderID's bta3ed el user
        //Hna hgeb tfasel kol order
      //  ArrayList<String>Orders=new ArrayList<String>();
        HashMap<String, String> MyOrders = new HashMap<String, String>();
        for (int i=0;i<OrderIDs.size();i++)
        {
            MyDataBase=getReadableDatabase();
            arg= new String[]{OrderIDs.get(i)};
            Cursor cursor=MyDataBase.rawQuery("select Pro_ID , Quantity from OrderDetails where Ord_ID =?",arg);

            if (cursor.getCount()>0) {

                cursor.moveToFirst();
                String ProID=cursor.getString(0);
                String ProName=GetProductName(ProID);
                int Quantity=Integer.valueOf(cursor.getString(1));
                MyOrders.put(ProName,String.valueOf(Quantity));

               // Orders.add(cursor.getString(1)); //ProID
                //Orders.add(cursor.getString(2)); //Quantity
                MyDataBase.close();
            }
            MyDataBase.close();

            cursor.close();


        }
        return MyOrders;


    }
    public void insertProduct(ProductModel product){
        MyDataBase=getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("ProName",product.getProName());
        values.put("ProImage",product.getProImage());
        values.put("price",product.getPrice());
        values.put("quantity",product.getPro_quantity());
        values.put("barcode",product.getBarCode());
        values.put("Cat_ID",product.getCatId());

        MyDataBase.insert("Products",null,values);
        MyDataBase.close();
    }
    public String GetCatID(String name ){
        MyDataBase=getReadableDatabase();
        String[]args={name};
        Cursor cursor=MyDataBase.rawQuery("select CatID from Category where CatName =?",args);

        if (cursor.getCount()>0) {

            cursor.moveToFirst();
            MyDataBase.close();
            return cursor.getString(0);
        }
        MyDataBase.close();

        cursor.close();
        return null;

    }
    public String GetProID(String name ){
        MyDataBase=getReadableDatabase();
        String[]args={name};
        Cursor cursor=null;
       try {
           cursor=MyDataBase.rawQuery("select ProID from Products where ProName =?",args);

        if (cursor.getCount()>0) {

            cursor.moveToFirst();
            MyDataBase.close();
            return cursor.getString(0);
        }
        MyDataBase.close();
       }

      finally  {cursor.close();}
        return null;

    }
    public void ChangePassord(String Email,String NewPassword)
    {


        MyDataBase=getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("Password",NewPassword); //These Fields should be your String values of actual column names
        MyDataBase.update("Customers", cv, "Email = ?", new String[]{Email});



    }
    public String GetCustID(String Email ){
        MyDataBase=getReadableDatabase();
        String[]args={Email};
        Cursor cursor=MyDataBase.rawQuery("select CustID from Customers where Email =?",args);

        if (cursor.getCount()>0) {

            cursor.moveToFirst();
            MyDataBase.close();
            return cursor.getString(0);
        }
        MyDataBase.close();

        cursor.close();
        return null;

    }
    public void insertCategory(CategoryModel cate){
        MyDataBase=getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("CatName",cate.getCat_name());
        MyDataBase.insert("Category",null,values);
        MyDataBase.close();
    }
    public Cursor userLogin(String Email, String pass) {
        MyDataBase = getReadableDatabase();
        String[] args = {Email, pass};
        //database.query("customer","id",raw,null,null,null,null,null);
        Cursor cursor = MyDataBase.rawQuery("select CustID from Customers where Email =? and  Password =? ", args);

        if (cursor != null)
            cursor.moveToFirst();

        MyDataBase.close();
        return cursor;

    }
    public Bitmap getImage(String Email,String Password){


        String[] args = {Email, Password};
        MyDataBase=getReadableDatabase();
        Cursor cursor = MyDataBase.rawQuery("select Image from Customers where Email =? and  Password =? ", args);
        if (cursor.moveToFirst()){
            byte[] imgByte = cursor.getBlob(0);
            cursor.close();
            return BitmapFactory.decodeByteArray(imgByte, 0, imgByte.length);
        }
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }

        return null;
    }



    public Cursor getCategory(){
        MyDataBase=getReadableDatabase();
        String []fields={"CatID","CatName"};
        Cursor cursor= MyDataBase.query("Category",fields,null,null,null,null,null);

        if (cursor.getCount()>0)
            cursor.moveToFirst();

        MyDataBase.close();

        return cursor;
    }
}
