package com.example.eco;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.FragmentTransaction;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.service.quickaccesswallet.QuickAccessWalletService;
import android.util.DisplayMetrics;
import android.util.SparseIntArray;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eco.Model.CategoryModel;
import com.example.eco.Model.ProductModel;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import static java.lang.Double.parseDouble;

public class twoCart extends AppCompatActivity {
    TableLayout layout;
    Intent openMainActivity;
    String Lat;
    String Longt;
    Double finalTotalPrice;
    String Email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_two_cart);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        // Passing each menu ID as a set of Ids because each
        // menu should be considered as top level destinations.
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        Bundle extras = getIntent().getExtras();
         Email = extras.getString("Email");
        String Password = extras.getString("Password");

        /*NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);*/
        //  navView.setSelectedItemId(R.id.Cart);

        MyDatabaseClass Db = new MyDatabaseClass(getApplicationContext());
        String ID = Db.GetCustID(Email);
        HashMap<String, String> Orders = Db.GetOrders(ID, Email);


        layout = findViewById(R.id.simpleGridViewCart);
        layout.removeAllViews();
        final Double[] TotalPrice = {0.0};
        LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        TextView TotalPrice_TextView;
        TotalPrice_TextView = new TextView(twoCart.this);
        ImageView Confirm = null;
        for (Map.Entry me : Orders.entrySet()) {

                TableLayout CustomtableLayout = new TableLayout(twoCart.this);
                String ProID = Db.GetProID(me.getKey().toString());
                Bitmap ProdImage = Db.getProdImageByProdID(ProID);
                ImageView imageView = new ImageView(twoCart.this);
                imageView.setImageBitmap(ProdImage);
                TableLayout.LayoutParams layoutParams = new TableLayout.LayoutParams();

            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
                layoutParams.height = displayMetrics.heightPixels/3;
                layoutParams.width =  displayMetrics.widthPixels/3;
                layoutParams.setMargins(0, 0, 0, 0);
                imageView.setLayoutParams(layoutParams);
                //layout.addView(imageView);
                TextView textView;
                textView = new TextView(twoCart.this);
                String ProName = me.getKey().toString();
                Double Pr = Double.valueOf(Db.GetProductPrice(ProID));

                textView.setText("\n \n " + ProName + "\n \n  Price: " + String.valueOf(Pr) + "\n");
                textView.setTextSize((float) (displayMetrics.widthPixels / 45));
                textView.setGravity(Gravity.CENTER);
                LinearLayout layoutRow2 = new LinearLayout(twoCart.this);
                LinearLayout linearLayoutPricaAndQuantity = new LinearLayout(getApplicationContext());
                linearLayoutPricaAndQuantity.setOrientation(LinearLayout.VERTICAL);
                linearLayoutPricaAndQuantity.addView(textView);
                RelativeLayout relativeLayout = new RelativeLayout(twoCart.this);
                //layoutRow2.setWeightSum(3);
                //layoutRow2.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.FILL_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
                relativeLayout.addView(imageView);


                ImageView RemoveItem;
                RemoveItem = new ImageView(twoCart.this);
                RemoveItem.setImageDrawable(getResources().getDrawable(R.drawable.remove));

                layoutParams2.height =  displayMetrics.heightPixels/10;
                layoutParams2.width =  displayMetrics.widthPixels/10;
                layoutParams2.setMargins(25, 75, 0, 0);
                //layoutParams2.gravity=Gravity.RIGHT;
                RemoveItem.setLayoutParams(layoutParams2);

                relativeLayout.addView(RemoveItem);
                layoutRow2.addView(relativeLayout);
                final int[] quantity = {Db.GetProductQuantity(ProName)};
                Spinner spinnerQuantity = new Spinner(getApplicationContext());
                ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(twoCart.this, android.R.layout.simple_list_item_1);
                for (int k = 1; k < quantity[0] + 1; k++) {
                    arrayAdapter.add(String.valueOf(k));
                }
                spinnerQuantity.setAdapter(arrayAdapter);
                LinearLayout QuantityLayout = new LinearLayout(getApplicationContext());
                QuantityLayout.setOrientation(LinearLayout.HORIZONTAL);
                TextView Qua = new TextView(getApplicationContext());
                Qua.setText("Quantity: ");
                Qua.setTextSize((float) (displayMetrics.widthPixels / 45));
                ImageView minus = new ImageView(getApplicationContext());
                minus.setImageResource(R.drawable.ic_baseline_chevron_left_24);
                ImageView plus = new ImageView(getApplicationContext());
                plus.setImageResource(R.drawable.ic_baseline_chevron_right_24);
                plus.setColorFilter(R.color.black);
                TextView Quanta = new TextView(getApplicationContext());
                Quanta.setTextSize((float) (displayMetrics.widthPixels / 45));
                Quanta.setText(me.getValue().toString());

                minus.setColorFilter(R.color.black);

                QuantityLayout.addView(Qua);
                QuantityLayout.addView(minus,new LinearLayout.LayoutParams(displayMetrics.widthPixels / 12, displayMetrics.heightPixels / 12));
                QuantityLayout.addView(Quanta);
                QuantityLayout.addView(plus,new LinearLayout.LayoutParams(displayMetrics.widthPixels / 12, displayMetrics.heightPixels / 12));

                linearLayoutPricaAndQuantity.addView(QuantityLayout);
                layoutRow2.addView(linearLayoutPricaAndQuantity);
                final int MaxQuantity = quantity[0];
                quantity[0] = Db.GetProductQuantityFromOrder(ProName, Email);
                quantity[0] = Integer.valueOf(me.getValue().toString());
                // Quanta.setText(me.getValue().toString());

                TotalPrice[0] += Pr * quantity[0];
                TotalPrice_TextView.setText("Total Price: " + String.valueOf(TotalPrice[0]));
            TotalPrice_TextView.setTextSize((float) (displayMetrics.widthPixels / 45));

            plus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {


                        if (quantity[0] > MaxQuantity) {
                            plus.setEnabled(false);
                            minus.setEnabled(true);
                            return;
                        }
                        minus.setEnabled(true);
                        quantity[0]++;
                        Db.SetProductQuantityAtOrder(ProName, quantity[0]);
                        if (quantity[0] > MaxQuantity) {
                            quantity[0]--;
                            Db.SetProductQuantityAtOrder(ProName, quantity[0]);

                            return;
                        }
                        TotalPrice[0] += Pr;

                        TotalPrice_TextView.setText("Total Price: " + String.valueOf(TotalPrice[0]));
                        Quanta.setText(String.valueOf(quantity[0]));

                    }
                });
                minus.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (quantity[0] != 0 && quantity[0] > 0) {
                            if (quantity[0] == 1) {
                                plus.setEnabled(true);
                                minus.setEnabled(false);
                                return;
                            }
                            TotalPrice[0] -= Pr;
                            quantity[0]--;
                            Db.SetProductQuantityAtOrder(ProName, quantity[0]);

                            Quanta.setText(String.valueOf(quantity[0]));
                            TotalPrice_TextView.setText("Total Price: " + String.valueOf(TotalPrice[0]));
                            plus.setEnabled(true);
                        }
                    }
                });
                spinnerQuantity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {


                        TotalPrice[0] += Pr * Double.valueOf(spinnerQuantity.getSelectedItem().toString());
                        TotalPrice_TextView.setText("Total Price: " + String.valueOf(TotalPrice[0]));
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                });


                layout.addView(layoutRow2);
                //  final int Ord_ID = Integer.valueOf(Orders.get(i));
                final String ProNa = ProName;
                RemoveItem.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Db.RemoveOrder(ProName);
                        Intent i = new Intent(getApplicationContext(), twoCart.class);
                        i.putExtra("Email", Email);
                        i.putExtra("Password", Password);
                        startActivity(i);
                        overridePendingTransition(0, 0);
                        finish();


                    }
                });



        }

            TotalPrice_TextView.setText("Total Price: " + String.valueOf(TotalPrice[0]));
            TotalPrice_TextView.setGravity(Gravity.LEFT);
           layout.removeView(TotalPrice_TextView);

            Confirm = new ImageView(twoCart.this);
            Confirm.setImageDrawable(getResources().getDrawable(R.drawable.confirm));
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            layoutParams2.height =displayMetrics.heightPixels / 5;
            layoutParams2.width = displayMetrics.widthPixels / 5;
            //layoutParams2.setMargins(25,75,0,0);

            //Confirm.setBackgroundColor(0xFF21AA2C);
            Confirm.setLayoutParams(layoutParams2);
         //   layout.removeView(Confirm);
             finalTotalPrice = TotalPrice[0];
            if (finalTotalPrice == 0.0) {
                Confirm.setVisibility(View.GONE);
            }
            ImageView finalConfirm = Confirm;
            Confirm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(twoCart.this);

                    // set title
                    alertDialogBuilder.setTitle("Confirmation");

                    // set dialog message

                    alertDialogBuilder
                            .setMessage("Are you sure to confirm these orders with total " + finalTotalPrice.toString() + " ?")
                            .setCancelable(false)
                            .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {


                                    AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(twoCart.this);

                                    // set title
                                    alertDialogBuilder2.setTitle("Address");

                                    // set dialog message
                                    EditText MyAddress=new EditText(getApplicationContext());
                                    alertDialogBuilder2
                                            .setMessage("Enter Ur Address or use GPS/G_Maps .." )
                                            .setCancelable(false).setView(MyAddress)
                                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {

                                                    if (!MyAddress.getText().equals("")) {
                                                        //#Sending Mail
                                                        String mEmail = Email;
                                                        String mSubject = "Confirmation Order";
                                                        String mMessage = "Your order has been confirmed Successfully ";


                                                        JavaMailAPI javaMailAPI = new JavaMailAPI(getApplicationContext(), mEmail, mSubject, mMessage);

                                                        javaMailAPI.execute();
                                                        MyDatabaseClass Db = new MyDatabaseClass(getApplicationContext());
                                                        Db.ConfirmOrder(Email,MyAddress.getText().toString());
                                                        layout.removeAllViews();

                                                        Toast.makeText(getApplicationContext(), "Confirmation sent to your Mail", Toast.LENGTH_LONG).show();

                                                    }
                                                }
                                            })
                                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                                public void onClick(DialogInterface dialog, int id) {
                                                    //  Toast.makeText(Admin.this, "CANCEL button click ", Toast.LENGTH_SHORT).show();

                                                    dialog.cancel();
                                                }
                                            }).setNeutralButton("Google Maps", new DialogInterface.OnClickListener() {

                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {


                                        //     Toast.makeText(getApplicationContext(),MainActivity.Lon,Toast.LENGTH_LONG).show();
                                             openMainActivity = new Intent(twoCart.this, MainActivity.class);
                                            openMainActivity.putExtra("Long","Long");
                                            openMainActivity.putExtra("Lat","Lat");
                                            openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                            startActivityForResult(openMainActivity, 0);
                                            String str = openMainActivity.getStringExtra("Lat");

                                         //   Toast.makeText(getApplicationContext(),"IBRaHIM << "+str,Toast.LENGTH_LONG).show();

                                            //   Intent in=new Intent(getApplicationContext(),twoCart.class);



                                           /* Uri gmmIntentUri = Uri.parse("geo:37.7749,-122.4194?q=restaurants");
                                            Intent mapIntent = new Intent(Intent.ACTION_VIEW, gmmIntentUri);
                                            mapIntent.setPackage("com.google.android.apps.maps");
                                            startActivity(mapIntent);

                                            */


                                        }
                                    });

                                    AlertDialog alertDialog2 = alertDialogBuilder2.create();

                                    // show it
                                    alertDialog2.show();








                                    //Lsa Hkml Hna

                                  //  Db.RemoveProductsFromDatabase(Orders);
                                    // Toast.makeText(getApplicationContext(),"Updated",Toast.LENGTH_SHORT).show();
                                  //  finalConfirm.setVisibility(View.GONE);


                                }
                            })
                            .setNegativeButton("No", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    //  Toast.makeText(Admin.this, "CANCEL button click ", Toast.LENGTH_SHORT).show();

                                    dialog.cancel();
                                }
                            });

                    // create alert dialog
                    AlertDialog alertDialog = alertDialogBuilder.create();

                    // show it
                    alertDialog.show();


                }
            });


            navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                    switch (item.getItemId()) {
                        case R.id.shop:
                            //navView.setSelectedItemId(R.id.shop);
                            Intent i = new Intent(getApplicationContext(), oneHome.class);
                            i.putExtra("Email", Email);
                            i.putExtra("Password", Password);
                            startActivity(i);
                            overridePendingTransition(0, 0);
                            finish();
                            return true;
                        case R.id.Cart:
                            //  navView.setSelectedItemId(R.id.Cart);
                            return true;
                        case R.id.profile:
                            //  navView.setSelectedItemId(R.id.profile);
                            Intent i2 = new Intent(getApplicationContext(), threeProfile.class);
                            i2.putExtra("Email", Email);
                            i2.putExtra("Password", Password);
                            startActivity(i2);
                            overridePendingTransition(0, 0);
                            finish();
                            return true;

                    }

                    return false;
                }
            });

        layout.addView(TotalPrice_TextView);
        layout.addView(Confirm);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode,  Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

            Lat=data.getStringExtra("Lat");
            Longt=data.getStringExtra("Long");


        Geocoder geocoder;
        List<Address> addresses = null;
        geocoder = new Geocoder(this, Locale.getDefault());

        try {
            addresses = geocoder.getFromLocation(parseDouble(Lat), parseDouble(Longt), 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
        } catch (IOException e) {
            e.printStackTrace();
        }

        String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
        String city = addresses.get(0).getLocality();
        String state = addresses.get(0).getAdminArea();
        String country = addresses.get(0).getCountryName();
        String postalCode = addresses.get(0).getPostalCode();
        String knownName = addresses.get(0).getFeatureName(); // Only if available else return NULL


        Cont((address));

















    }


    void Cont(String FullAddress)
    {


        AlertDialog.Builder ConfirmWithPriceDialog = new AlertDialog.Builder(twoCart.this);

        // set title
        ConfirmWithPriceDialog.setTitle("Confirmation");

        // set dialog message

        ConfirmWithPriceDialog
                .setMessage("Are you sure to confirm these orders with total " + finalTotalPrice.toString() + " ?")
                .setCancelable(false)
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {

                        // layout.removeAllViews();






                        AlertDialog.Builder AddressConfirmDialgueFirst = new AlertDialog.Builder(twoCart.this);

                        // set title
                        AddressConfirmDialgueFirst.setTitle("Address");

                        // set dialog message
                        EditText MyAddress=new EditText(getApplicationContext());
                        MyAddress.setText(FullAddress);
                        AddressConfirmDialgueFirst
                                .setMessage("Enter Ur Address or use GPS/G_Maps .." )
                                .setCancelable(false).setView(MyAddress)
                                .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                        if (!MyAddress.getText().equals("")) {
                                            //#Sending Mail
                                            String mEmail = Email;
                                            String mSubject = "Confirmation Order";
                                            String mMessage = "Your order has been confirmed Successfully ";


                                            JavaMailAPI javaMailAPI = new JavaMailAPI(getApplicationContext(), mEmail, mSubject, mMessage);

                                            javaMailAPI.execute();
                                            MyDatabaseClass Db = new MyDatabaseClass(getApplicationContext());
                                            Db.ConfirmOrder(Email,MyAddress.getText().toString());
                                            layout.removeAllViews();

                                            Toast.makeText(getApplicationContext(), "Confirmation sent to your Mail", Toast.LENGTH_LONG).show();

                                                       }
                                    }
                                })
                                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Toast.makeText(Admin.this, "CANCEL button click ", Toast.LENGTH_SHORT).show();

                                        dialog.cancel();
                                    }
                                }).setNeutralButton("Google Maps", new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {


                                //     Toast.makeText(getApplicationContext(),MainActivity.Lon,Toast.LENGTH_LONG).show();
                                openMainActivity = new Intent(twoCart.this, MainActivity.class);
                                openMainActivity.putExtra("Long","Long");
                                openMainActivity.putExtra("Lat","Lat");
                                openMainActivity.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                                startActivityForResult(openMainActivity, 0);
                                String str = openMainActivity.getStringExtra("Lat");

                                //Toast.makeText(getApplicationContext(),"IBRaHIM << "+str,Toast.LENGTH_LONG).show();

                               

                            }
                        });

                        AlertDialog alertDialog2 = AddressConfirmDialgueFirst.create();

                        // show it
                        alertDialog2.show();



                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //  Toast.makeText(Admin.this, "CANCEL button click ", Toast.LENGTH_SHORT).show();

                        dialog.cancel();
                    }
                });

        // create alert dialog
        AlertDialog alertDialog = ConfirmWithPriceDialog.create();

        // show it
        alertDialog.show();


    }







        }




