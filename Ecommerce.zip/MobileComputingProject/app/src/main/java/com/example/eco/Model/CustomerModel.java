package com.example.eco.Model;

import android.icu.lang.UProperty;

public class CustomerModel {

    private int id;
    private String custName, password, gender, custJop,custBirthDate,Email;
    private byte[]img;

    public CustomerModel() {
    }

    public CustomerModel(String custName,  String password, String gender, String custJop, String custBirthDate,byte[]img,String Email) {
        this.custName = custName;
        this.password = password;
        this.gender = gender;
        this.custJop = custJop;
        this.custBirthDate = custBirthDate;
        this.img=img;
        this.Email=Email;
    }

    public int getId() {
        return id;
    }
    public byte[] getImg() {
        return img;
    }



    public void setId(int id) {
        this.id = id;
    }
    public String getEmail() {
        return Email;
    }



    public void setEmail(String Email) {
        this.Email = Email;
    }
    public void setImg(byte[] img) {
        this.img = img;
    }

    public String getCustName() {
        return custName;
    }

    public void setCustName(String custName) {
        this.custName = custName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getCustJop() {
        return custJop;
    }

    public void setCustJop(String custJop) {
        this.custJop = custJop;
    }

    public String getCustBirthDate() {
        return custBirthDate;
    }

    public void setCustBirthDate(String custBirthDate) {
        this.custBirthDate = custBirthDate;
    }
}
