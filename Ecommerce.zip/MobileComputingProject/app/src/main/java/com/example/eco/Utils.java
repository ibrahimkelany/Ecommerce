package com.example.eco;

public class Utils {
    // HERE PUT EMAIL AND PASSWORD , LIKE example@gmail.com

    public static final  String EMAIL = "eco.2020.2021.2022@gmail.com";
    public static final String PASSWORD = "ibrahim@2021";
}
