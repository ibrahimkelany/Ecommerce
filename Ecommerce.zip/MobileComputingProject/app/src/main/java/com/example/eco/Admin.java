package com.example.eco;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.ViewModelProvider;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eco.Model.CategoryModel;
import com.example.eco.Model.ProductModel;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;


public class Admin extends AppCompatActivity {
    private ConstraintLayout constraintLayout;
    private AnimationDrawable animationDrawable;
    private  static final int Gallery_Request_Code=123;
    private Spinner spinner;
    MyDatabaseClass Db;
    ArrayAdapter adapter;
    
    Button btn_upload;
    ImageView imageButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);

        getSupportActionBar().hide();
        // init constraintLayout
        constraintLayout = (ConstraintLayout) findViewById(R.id.constraintLayout);
        // initializing animation drawable by getting background from constraint layout
        animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        // setting enter fade animation duration to 3 seconds
        animationDrawable.setEnterFadeDuration(1000);
        // setting exit fade animation duration to 2 seconds
        animationDrawable.setExitFadeDuration(500);
        ImageView Logout=findViewById(R.id.adminLogOutBtn);
        Logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent LogIn=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(LogIn);
                finish();
            }
        });
         btn_upload=findViewById(R.id.btn_upload);
         imageButton=findViewById(R.id.product_image);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"),Gallery_Request_Code);
            }
        });
        EditText product_price= findViewById(R.id.product_price);

        EditText product_name= findViewById(R.id.product_name);
        EditText product_quantity= findViewById(R.id.product_quantity);
         spinner=findViewById(R.id.category);

        btn_upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(!product_name.getText().toString().equals("")&&!product_price.getText().toString().equals("")&&!product_quantity.getText().toString().equals("")&&!spinner.getSelectedItem().toString().equals("")) {
                    ProductModel model = new ProductModel();
                    model.setPrice(Double.valueOf(product_price.getText().toString()));
                    model.setPro_quantity(Integer.valueOf(product_quantity.getText().toString()));
                    model.setProName((product_name.getText().toString()));


                    Bitmap bitmap = ((BitmapDrawable) imageButton.getDrawable()).getBitmap();
                    ByteArrayOutputStream stream = new ByteArrayOutputStream();
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                    byte[] byteArray = stream.toByteArray();
                    model.setProImage(byteArray);
                    Db = new MyDatabaseClass(getApplicationContext());
                    model.setCatId(Integer.valueOf(Db.GetCatID(spinner.getSelectedItem().toString())));


                    MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
                    try {
                        BitMatrix bitMatrix = multiFormatWriter.encode(product_name.getText().toString(), BarcodeFormat.CODE_128, 400, 200);
                        Bitmap bitmap2 = Bitmap.createBitmap(400,200, Bitmap.Config.RGB_565);
                        for (int i = 0; i<400; i++){
                            for (int j = 0; j<200; j++){
                                bitmap2.setPixel(i,j,bitMatrix.get(i,j)? Color.BLACK: Color.WHITE);
                            }
                        }
                         stream = new ByteArrayOutputStream();
                        bitmap2.compress(Bitmap.CompressFormat.PNG, 100, stream);
                        byte[] byteArray2 = stream.toByteArray();
                        model.setBarCode(byteArray2);
                        Db.insertProduct(model);
                       // imageView.setImageBitmap(bitmap2);
                    } catch (WriterException e) {
                        e.printStackTrace();
                    }







                    product_name.setText("");
                    product_price.setText("");
                    product_quantity.setText("");
                    imageButton.setImageResource(R.drawable.img);

                    Toast.makeText(getApplicationContext(),"Done",Toast.LENGTH_LONG);

                }
                else
                {
                    Toast.makeText(getApplicationContext(),"Failed",Toast.LENGTH_LONG);
                }

            }
        });
        TextView reset=findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                product_name.setText("");
                product_price.setText("");
                product_quantity.setText("");
                imageButton.setImageResource(R.drawable.img);
            }
        });


        adapter=GetCategories();
        spinner.setAdapter(adapter);
        ImageView imageCat=findViewById(R.id.imageCat);
                final List<String> list = new ArrayList<String>();
        imageCat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             //String newCategoryName=  ShowPopUp();

                AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Admin.this);

                // set title
                alertDialogBuilder.setTitle("Add new category");

                // set dialog message
                EditText input=new EditText(getApplicationContext());
                alertDialogBuilder
                        .setMessage("Insert category name ...")
                        .setCancelable(false).setView(input).setIcon(R.drawable.addcate)
                        .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                txtInput =input.getText().toString();
                                Db=new MyDatabaseClass(getApplicationContext());
                                CategoryModel model=new CategoryModel();
                                model.setCat_name(txtInput);

                                if(!txtInput.equals("Def"))
                                {
                                    Db.insertCategory(model);
                                    adapter=GetCategories();
                                    spinner.setAdapter(adapter);
                                    Toast.makeText(Admin.this, "Done", Toast.LENGTH_SHORT).show();



                                }




                            }
                        })
                        .setNegativeButton("CANCEL",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                //  Toast.makeText(Admin.this, "CANCEL button click ", Toast.LENGTH_SHORT).show();

                                dialog.cancel();
                            }
                        });

                // create alert dialog
                AlertDialog alertDialog = alertDialogBuilder.create();

                // show it
                alertDialog.show();
















            }
        });


    }
    public String txtInput="Def";
    ArrayAdapter GetCategories( )
    {  List<String>cate=new ArrayList<>();
        ArrayAdapter add = null;
        Db=new MyDatabaseClass(getApplicationContext());
        Cursor cursor=Db.getCategory();
        if (cursor!=null){
            while (!cursor.isAfterLast()){
                cate.add(cursor.getString(1));
                cursor.moveToNext();
            }
            add=new ArrayAdapter(Admin.this,android.R.layout.simple_list_item_1,cate);


        }
        return add;
    }
   String ShowPopUp()
   {
       AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(Admin.this);

       // set title
       alertDialogBuilder.setTitle("Add new category");

       // set dialog message
       EditText input=new EditText(getApplicationContext());
       alertDialogBuilder
               .setMessage("Insert category name ...")
               .setCancelable(false).setView(input).setIcon(R.drawable.addcate)
               .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                       txtInput =input.getText().toString();
                       Db=new MyDatabaseClass(getApplicationContext());
                       CategoryModel model=new CategoryModel();
                       model.setCat_name(txtInput);
                       Db.insertCategory(model);
                       adapter=GetCategories();
                       spinner.setAdapter(adapter);
                       Toast.makeText(Admin.this, "Done", Toast.LENGTH_SHORT).show();

                   }
               })
               .setNegativeButton("CANCEL",new DialogInterface.OnClickListener() {
                   public void onClick(DialogInterface dialog, int id) {
                     //  Toast.makeText(Admin.this, "CANCEL button click ", Toast.LENGTH_SHORT).show();

                       dialog.cancel();
                   }
               });

       // create alert dialog
       AlertDialog alertDialog = alertDialogBuilder.create();

       // show it
       alertDialog.show();
       Toast.makeText(getApplicationContext(),txtInput,Toast.LENGTH_SHORT);
       return txtInput;
   }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Gallery_Request_Code && resultCode == RESULT_OK && data != null) {
            Uri imageData = data.getData();
            imageButton.setImageURI(imageData);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (animationDrawable != null && !animationDrawable.isRunning()) {
            // start the animation
            animationDrawable.start();
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        if (animationDrawable != null && animationDrawable.isRunning()) {
            // stop the animation
            animationDrawable.stop();
        }
    }
}