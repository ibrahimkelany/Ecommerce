package com.example.eco;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;

import com.example.eco.Model.CustomerModel;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import java.io.ByteArrayOutputStream;
import java.util.Calendar;

public class Register extends AppCompatActivity {
    private ConstraintLayout constraintLayout;
  //  final Calendar myCalendar = Calendar.getInstance();

    private AnimationDrawable animationDrawable;
    private  static final int Gallery_Request_Code=123;
    byte[] byteArray;
ImageView imageButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        Bundle extras = getIntent().getExtras();

//        getSupportActionBar().hide();
        constraintLayout = (ConstraintLayout) findViewById(R.id.constraintLayout);
        // initializing animation drawable by getting background from constraint layout
        animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        // setting enter fade animation duration to 3 seconds
        animationDrawable.setEnterFadeDuration(3000);
        // setting exit fade animation duration to 2 seconds
        animationDrawable.setExitFadeDuration(2000);


        imageButton=findViewById(R.id.RegImage);
        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"),Gallery_Request_Code);
                imageButton.getLayoutParams().height=200;
            }
        });


        final DatePickerDialog[] picker = null;

        EditText usernameEditText =(EditText) findViewById(R.id.username2);
        EditText passwordEditText =(EditText) findViewById(R.id.password2);
        EditText dateEditText =(EditText) findViewById(R.id.date);
        EditText titleEditText =(EditText) findViewById(R.id.jobtitle);
        EditText EmailEditText =(EditText) findViewById(R.id.Email2);
        Button reg =(Button) findViewById(R.id.registerbtn);
        Spinner gender=findViewById(R.id.gender4);

        final String[] UserName = new String[1];
        final String[] Password = new String[1];
        ImageView datebutton=findViewById(R.id.dateIcon);
        datebutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Calendar C=Calendar.getInstance();
               int day=C.get(Calendar.DAY_OF_MONTH);
               int Month=C.get(Calendar.MONTH);
               int Year=C.get(Calendar.YEAR);
               DatePickerDialog datePickerDialog=new DatePickerDialog(Register.this, new DatePickerDialog.OnDateSetListener() {
                   @Override
                   public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                       month++;
                       dateEditText.setText(dayOfMonth+"/"+month+"/"+year);
                   }
               },Year,Month,day);
               datePickerDialog.show();
            }
        });

        if (extras != null) {
             UserName[0] = extras.getString("Email");
             Password[0] = extras.getString("Password");
            EmailEditText.setText(UserName[0]);
            passwordEditText.setText(Password[0]);
        }



        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CustomerModel m=new CustomerModel();
                m.setPassword(passwordEditText.getText().toString());
                m.setGender( gender.getSelectedItem().toString());
                m.setCustName(usernameEditText.getText().toString());
                m.setCustJop(titleEditText.getText().toString());
                m.setCustBirthDate(dateEditText.getText().toString());
                m.setEmail(EmailEditText.getText().toString());
                Bitmap bitmap = ((BitmapDrawable) imageButton.getDrawable()).getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byteArray = stream.toByteArray();
                m.setImg(byteArray);

                MyDatabaseClass DB=new MyDatabaseClass(getApplicationContext());
                DB.AddCustomer(m);
                finish();

            }
        });


    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == Gallery_Request_Code && resultCode == RESULT_OK && data != null) {
            Uri imageData = data.getData();
            imageButton.setImageURI(imageData);
        }
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (animationDrawable != null && !animationDrawable.isRunning()) {
            // start the animation
            animationDrawable.start();
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        if (animationDrawable != null && animationDrawable.isRunning()) {
            // stop the animation
            animationDrawable.stop();
        }
    }

}