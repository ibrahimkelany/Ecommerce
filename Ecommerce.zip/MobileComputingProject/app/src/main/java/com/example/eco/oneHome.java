package com.example.eco;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.ui.AppBarConfiguration;

import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Display;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.eco.Model.ProductModel;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class oneHome extends AppCompatActivity {
    TableLayout layout;
    Intent openMainActivity;
    MyDatabaseClass Db;
    String Email;
    String Password;
    TextView textViewPib;
    Spinner catSpinner;
    String Bar;
    ArrayList<String> result;
    LinearLayout LayoutForScanAndShowCat;
    //int QuantityForU;
    private final int REQ_CODE_SPEECH_INPUT = 100;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_one_home);


        BottomNavigationView navView = findViewById(R.id.nav_view);

        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        ScrollView scrollView=findViewById(R.id.scrollView);

        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        BottomNavigationView bt=findViewById(R.id.nav_view);
        LinearLayout C2=findViewById(R.id.la2);
        TypedValue tv = new TypedValue();
        int actionBarHeight=0;
        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true))
        {
            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data,getResources().getDisplayMetrics());
        }
        C2.getLayoutParams().height =displayMetrics.heightPixels-(bt.getHeight()+actionBarHeight);
        C2.getLayoutParams().width=displayMetrics.widthPixels;

        Bundle extras = getIntent().getExtras();
        Email=extras.getString("Email");
         Password=extras.getString("Password");



        MyDatabaseClass Db=new MyDatabaseClass(getApplicationContext());

        layout=findViewById(R.id.simpleGridView);
         catSpinner =new Spinner(getApplicationContext());

        catSpinner.setAdapter(GetCategories());


         LayoutForScanAndShowCat=new LinearLayout(getApplicationContext());
        LayoutForScanAndShowCat.setOrientation(LinearLayout.HORIZONTAL);
        LayoutForScanAndShowCat.setWeightSum(2);
        WindowManager w = getWindowManager();
        Display d = w.getDefaultDisplay();

      LayoutForScanAndShowCat.addView(catSpinner);

        layout.addView(LayoutForScanAndShowCat);
        //layout.addView(catSpinner);


//        setContentView(layout);
        catSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

                String selected = catSpinner.getSelectedItem().toString();
                if(!selected.equals("All"))
                {
                    layout.removeAllViews();
                    layout.addView(LayoutForScanAndShowCat);

                    Show(Db.GetProducts(selected),Db.GetAllProductsImages(selected));
                }
                else
                {
                    layout.removeAllViews();
                    layout.addView(LayoutForScanAndShowCat);
                    Show(  Db.GetProducts(),Db.GetAllProductsImages());
                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });


        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {


                switch (item.getItemId())
                {
                    case R.id.shop:
                  //      navView.setSelectedItemId(R.id.shop);
                        return true;
                    case R.id.Cart:
                       // navView.setSelectedItemId(R.id.Cart);
                        Intent i=new Intent(getApplicationContext(),twoCart.class);
                        i.putExtra("Email",Email);
                        i.putExtra("Password",Password);
                        startActivity(i);
                        overridePendingTransition(0,0);

                        finish();
                        return true;

                    case R.id.profile:
                      //  navView.setSelectedItemId(R.id.profile);

                        Intent i2=new Intent(getApplicationContext(),threeProfile.class);
                        i2.putExtra("Email",Email);
                        i2.putExtra("Password",Password);


                        startActivity(i2);
                        overridePendingTransition(0,0);
                        finish();

                        return true;

                }

                return false;
            }
        });

    }

    public String txtInput="Def";

    void AddCustomView(ImageView imageView, int width, int height, ProductModel model)
    {


        TableLayout.LayoutParams layoutParams=new TableLayout.LayoutParams();
        layoutParams.height=height;
        layoutParams.width=width;
        layoutParams.setMargins(0,0,0,0);
        imageView.setLayoutParams(layoutParams);
        layout.addView(imageView);
        TextView textView=new TextView(oneHome.this);
        textView.setText(model.getProName());
        textView.setGravity(Gravity.CENTER);
        layout.addView(textView);
        textView=new TextView(oneHome.this);
       textView.setText("Price: "+String.valueOf(model.getPrice()));
        textView.setGravity(Gravity.CENTER);
        layout.addView(textView);
        textView=new TextView(oneHome.this);
        textView.setText("Available quantity: "+Db.GetProductQuantity(model.getProName()));
        textView.setGravity(Gravity.CENTER);
        layout.addView(textView);

        Db=new MyDatabaseClass(getApplicationContext());
        textView=new TextView(oneHome.this);

        textViewPib=new TextView(getApplicationContext());


        int FullProQuant=Db.GetProductQuantity(model.getProName());
        int UserProQuant=Db.GetProductQuantityFromOrder(model.getProName(),Email);
        int diff=FullProQuant-UserProQuant;
        if(diff==0)
        {
            textViewPib.setText("Not available now for You");
        }
        else
        {
            textViewPib.setText("Available quantity for You: "+String.valueOf(diff));

        }
        //  Toast.makeText(getApplicationContext(),model.getProName(),Toast.LENGTH_SHORT).show();
        textViewPib.setGravity(Gravity.CENTER);
        layout.addView(textViewPib);


    }
    ArrayAdapter GetCategories( )
    {  List<String> cate=new ArrayList<>();
        ArrayAdapter add = null;
        MyDatabaseClass Db=new MyDatabaseClass(getApplicationContext());
        Cursor cursor=Db.getCategory();
        if (cursor!=null){
            while (!cursor.isAfterLast()){
                cate.add(cursor.getString(1));
                cursor.moveToNext();
            }
            add=new ArrayAdapter(oneHome.this,android.R.layout.simple_list_item_1);
            add.add("All");
            for(int i=0;i<cate.size();i++) {

                add.add(cate.get(i));
            }
        }
        return add;
    }
    void Show( ArrayList<String>arr, ArrayList<Bitmap> Products)
    {
        Db=new MyDatabaseClass(getApplicationContext());
        ArrayList<String> spinnerArray = new ArrayList<String>();
        spinnerArray.add("one");
        spinnerArray.add("two");
        spinnerArray.add("three");
        spinnerArray.add("four");
        spinnerArray.add("five");

        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, spinnerArray);
        spinner.setAdapter(spinnerArrayAdapter);
        layout.addView(spinner);
        LayoutForScanAndShowCat.removeAllViews();
        layout.addView(catSpinner);


        for (int i=0;i<Products.size();i++)
        {

            ImageView imageView=new ImageView(oneHome.this);
            imageView.setImageBitmap(Products.get(i));
            ProductModel model=new ProductModel();
            int k=2*i+i;
            model.setProName(arr.get(k));
            model.setPrice(Double.valueOf(arr.get(k+1)));
            model.setPro_quantity(Integer.valueOf(arr.get(k+2)));
            DisplayMetrics displayMetrics = new DisplayMetrics();
            getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
            AddCustomView(imageView,displayMetrics.widthPixels/3,displayMetrics.heightPixels/3,model);





            Button btn=new Button(oneHome.this);
            btn.setText("Add to cart");
            btn.setCompoundDrawablesWithIntrinsicBounds(R.drawable.dd, 0, 0, 0);
            btn.setGravity(Gravity.CENTER);


            layout.addView(btn,new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT));

            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {






                        // String Address=ShowPopUp();
                        final String[] Quantity = {"Def"};

                        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(oneHome.this);

                        // set title
                        alertDialogBuilder.setTitle("Quantity");

                        // set dialog message
                        EditText input=new EditText(getApplicationContext());
                        input.setInputType(InputType.TYPE_CLASS_NUMBER);
                        alertDialogBuilder
                                .setMessage("Enter Your Quantity ...")
                                .setCancelable(false).setView(input).setIcon(R.drawable.addcate)
                                .setPositiveButton("Add", new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {

                                        Quantity[0] =input.getText().toString();

                                        //  Toast.makeText(getApplicationContext(), Address[0],Toast.LENGTH_SHORT).show();
                                        if(!Quantity[0].equals(""))
                                        {

                                        if (!Quantity[0].equals("Def")) {
                                            int v=Integer.valueOf(input.getText().toString());

                                            if(v>Db.GetProductQuantity(model.getProName()))
                                            {
                                                Quantity[0] ="Def";
                                                Toast.makeText(getApplicationContext(), "Faild, Quantity more than available ! ",Toast.LENGTH_LONG).show();
                                                return;
                                            }
                                           // model.setPro_quantity(model.getPro_quantity()-1);


                                           String dd= Db.GetProID(model.getProName());
                                         //  int Q=Db.GetProductQuantityFromOrder(model.getProName(),Email)+1;


                                            Db.AddOrder(Email,dd, Integer.valueOf(Quantity[0]), Email);

                                            String N=model.getProName();
                                         //   Db.SetProductQuantityAtOrder(N,Q);
                                            Quantity[0] ="Def";

                                            Toast.makeText(getApplicationContext(), model.getProName()+" Added",Toast.LENGTH_SHORT).show();
                                        }

                                        }





                                        // Toast.makeText(oneHome.this, "Done", Toast.LENGTH_SHORT).show();

                                    }
                                })
                                .setNegativeButton("CANCEL",new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int id) {
                                        //  Toast.makeText(Admin.this, "CANCEL button click ", Toast.LENGTH_SHORT).show();

                                        dialog.cancel();
                                    }
                                });

                        // create alert dialog
                        AlertDialog alertDialog = alertDialogBuilder.create();

                        // show it
                        alertDialog.show();

                }
            });

        }

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.sear,menu);
        MenuItem item=menu.findItem(R.id.search_icon);
        MenuItem Logout=menu.findItem(R.id.logout);
        MenuItem VoiceToTxtbtn=menu.findItem(R.id.SearchByVoiceActionBar);

        VoiceToTxtbtn.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                promptSpeechInput();
                return false;
            }
        });
        MenuItem SearchByCamera=menu.findItem(R.id.SearchByCameraActionBar);

        SearchByCamera.setOnMenuItemClickListener((new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                openMainActivity = new Intent(oneHome.this, ScannedBarcodeActivity.class);

                startActivityForResult(openMainActivity, 0);
                String str = openMainActivity.getStringExtra("Lat");
                return false;
            }
        }));


        Logout.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Intent LogIn=new Intent(getApplicationContext(),LoginActivity.class);
                startActivity(LogIn);
                finish();
                return false;
            }
        });
        SearchView searchView=(SearchView)item.getActionView();
        searchView.setQueryHint("Find Product ...");
        item.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                catSpinner.setEnabled(false);
                return false;
            }
        });
        searchView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                catSpinner.setEnabled(false);
            }
        });
        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                catSpinner.setEnabled(true);

                return false;
            }
        });
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
              //  layout.addView(catSpinner);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
    //            layout.removeView(catSpinner);
                layout.removeAllViews();
               layout.addView(LayoutForScanAndShowCat);
                catSpinner.setEnabled(false);
                Db=new MyDatabaseClass(getApplicationContext());
                ArrayList<String> arr=Db.GetProductsthatContains(newText);
                Show(arr,Db.GetAllProductsImagesThatContain(newText));

                return false;
            }
        });

        catSpinner.setEnabled(true);


        return super.onCreateOptionsMenu(menu);
    }

    private void promptSpeechInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault());
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"Speech Prompet");
        try {
            startActivityForResult(intent, REQ_CODE_SPEECH_INPUT);
        } catch (ActivityNotFoundException a) {
            Toast.makeText(getApplicationContext(),"Speech Not Supported",Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode) {
            case REQ_CODE_SPEECH_INPUT: {
                if (resultCode == RESULT_OK && null != data) {

                    result = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);


                    layout.removeAllViews();
                    layout.addView(LayoutForScanAndShowCat);
                 //   catSpinner.setEnabled(false);
                    Db = new MyDatabaseClass(getApplicationContext());
                    ArrayList<String> arr = Db.GetProductsthatContains(result.get(0));
                    Show(arr, Db.GetAllProductsImagesThatContain(result.get(0)));
                }

                break;
            }
            case 0: {
                Bar = data.getStringExtra("Bar");
                if(!Bar.equals("")) {
                    layout.removeAllViews();
                    layout.addView(LayoutForScanAndShowCat);
                    // catSpinner.setEnabled(false);
                    Db = new MyDatabaseClass(getApplicationContext());
                    ArrayList<String> arr = Db.GetProductsthatContains(Bar);
                    Show(arr, Db.GetAllProductsImagesThatContain(Bar));
                }
            }

        }
    }


}
