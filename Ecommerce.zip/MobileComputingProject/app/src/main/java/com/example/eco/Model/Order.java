package com.example.eco.Model;

import java.util.Date;

public class Order  {

    private int orderId,custId;
    private String orderAddress;
    private Date orderDate;


    public Order(int custId, String orderAddress, Date orderDate) {
        this.custId = custId;
        this.orderAddress = orderAddress;
        this.orderDate = orderDate;
    }

    public Order() {
    }

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public int getCustId() {
        return custId;
    }

    public void setCustId(int custId) {
        this.custId = custId;
    }

    public String getOrderAddress() {
        return orderAddress;
    }

    public void setOrderAddress(String orderAddress) {
        this.orderAddress = orderAddress;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }
}
