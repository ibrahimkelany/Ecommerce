package com.example.eco;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class threeProfile extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_three_profile);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        Bundle extras = getIntent().getExtras();
        String Email=extras.getString("Email");
        String Password=extras.getString("Password");




        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_home, R.id.navigation_dashboard, R.id.navigation_notifications)
                .build();
        TextView viewUserName=findViewById(R.id.ProfileName);
        viewUserName.setText(Email);
        MyDatabaseClass Db=new MyDatabaseClass(getApplicationContext());
        Bitmap UserImage=Db.getImage(Email,Password);
        ImageView UserView=findViewById(R.id.UserImage);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);

        LinearLayout C2=findViewById(R.id.threeLayout);
        TypedValue tv = new TypedValue();
        int actionBarHeight=0;
        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true))
        {
            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data,getResources().getDisplayMetrics());
        }
        C2.getLayoutParams().height =displayMetrics.heightPixels-(navView.getHeight()+actionBarHeight);
        C2.getLayoutParams().width=displayMetrics.widthPixels;


        // UserView.setImageBitmap(UserImage.createScaledBitmap(UserImage, 120, 120, false));
        if (android.os.Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP_MR1) {
            UserImage = Bitmap.createScaledBitmap(UserImage, UserView.getWidth(),UserView.getHeight(),true);
        }
        UserView.setImageBitmap(UserImage);
       // UserView.getLayoutParams().height=200;
        Button ShowChart=findViewById(R.id.showChartbtn);
        ShowChart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent intent = new Intent(threeProfile.this, PieChart.class);
                intent.putExtra("Email", Email);

                intent.setFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivityForResult(intent, 62);
            }
        });


    /*    NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
        NavigationUI.setupWithNavController(navView, navController);*/
      //  navView.setSelectedItemId(R.id.profile);
        navView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                switch (item.getItemId())
                {
                    case R.id.shop:
                        //navView.setSelectedItemId(R.id.shop);
                        Intent i=new Intent(getApplicationContext(),oneHome.class);
                        i.putExtra("Email",Email);
                        i.putExtra("Password",Password);
                        startActivity(i);
                        overridePendingTransition(0,0);
                        finish();
                        return true;
                    case  R.id.Cart:
                        //navView.setSelectedItemId(R.id.Cart);

                        Intent i2=new Intent(getApplicationContext(),twoCart.class);
                        i2.putExtra("Email",Email);
                        i2.putExtra("Password",Password);
                        startActivity(i2);
                        overridePendingTransition(0,0);
                        finish();

                        return true;
                    case R.id.profile:
                       // navView.setSelectedItemId(R.id.profile);
                        return true;


                }

                return false;
            }
        });
    }
}