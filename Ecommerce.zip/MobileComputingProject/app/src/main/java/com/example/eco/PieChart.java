package com.example.eco;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.TextView;
import android.widget.Toast;

import com.razerdp.widget.animatedpieview.AnimatedPieView;
import com.razerdp.widget.animatedpieview.AnimatedPieViewConfig;
import com.razerdp.widget.animatedpieview.callback.OnPieSelectListener;
import com.razerdp.widget.animatedpieview.data.IPieInfo;
import com.razerdp.widget.animatedpieview.data.SimplePieInfo;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

public class PieChart extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pie_chart);
        final TextView[] textView = {findViewById(R.id.chartTxtView)};
        textView[0].setText("Welcome");
        textView[0].setGravity(Gravity.CENTER);
        AnimatedPieView mAnimatedPieView = findViewById(R.id.animatedPieView);
        AnimatedPieViewConfig config = new AnimatedPieViewConfig();

        MyDatabaseClass Db=new MyDatabaseClass(getApplicationContext());
        Bundle extras = getIntent().getExtras();
       String Email = extras.getString("Email");

        HashMap<String, String>ConfirmedOrders=Db.GetConfirmedOrders(Email);
        config.startAngle(-90);
        int nextInt ;
        for (Map.Entry me : ConfirmedOrders.entrySet())
            {
                Random random = new Random();

                nextInt=random.nextInt(0xffffff + 1);
                IPieInfo info=new SimplePieInfo();
                config.addData(new SimplePieInfo(Float.parseFloat(me.getValue().toString()), Color.parseColor(String.format("#%06x", nextInt)), me.getKey().toString()),false)
                        .drawText(true).duration(1000).textSize(21).strokeMode(false).autoSize(true).animOnTouch(true).textMargin(8);



            }
        config.selectListener(new OnPieSelectListener<IPieInfo>() {
            @Override
            public void onSelectPie(@NonNull IPieInfo pieInfo, boolean isFloatUp) {
                 textView[0] =findViewById(R.id.chartTxtView);
                textView[0].setText("In "+ pieInfo.getDesc() +"\nYou bought "+ pieInfo.getValue() +" products");
                if(!isFloatUp)
                {
                    textView[0].setText("Welcome");
                }

            }
        });

        mAnimatedPieView.applyConfig(config);
        mAnimatedPieView.start();

    }
}