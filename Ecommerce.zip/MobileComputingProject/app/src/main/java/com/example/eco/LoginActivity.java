package com.example.eco;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.CursorWindow;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import java.lang.reflect.Field;


public class LoginActivity extends AppCompatActivity {
    private ConstraintLayout constraintLayout;
    private AnimationDrawable animationDrawable;
    private MyDatabaseClass DB;
    private String sharedPrefFile ="com.example.android.eco";
    SharedPreferences mPreferences;
    private String Email="Default";
    private String Password="Default";
    int[] Remem;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        getSupportActionBar().hide();
        try {
            Field field = CursorWindow.class.getDeclaredField("sCursorWindowSize");
            field.setAccessible(true);
            field.set(null, 100 * 1024 * 1024); //the 100MB is the new size
        } catch (Exception e) {
            if (BuildConfig.DEBUG) {
                e.printStackTrace();
            }
        }

        // init constraintLayout
        constraintLayout = (ConstraintLayout) findViewById(R.id.constraintLayout);
        // initializing animation drawable by getting background from constraint layout
        animationDrawable = (AnimationDrawable) constraintLayout.getBackground();
        // setting enter fade animation duration to 3 seconds
        animationDrawable.setEnterFadeDuration(3000);
        // setting exit fade animation duration to 2 seconds
        animationDrawable.setExitFadeDuration(2000);
        DB=new MyDatabaseClass(getApplicationContext());


         EditText EmailEditText =(EditText) findViewById(R.id.Email);
         EditText passwordEditText =(EditText) findViewById(R.id.password);
         Button loginButton =(Button) findViewById(R.id.loginbtn);
        ImageView ShowPassword=findViewById(R.id.showPassword);
        ShowPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (passwordEditText.getTransformationMethod()==HideReturnsTransformationMethod.getInstance()) {
                   // passwordEditText.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                  passwordEditText.setTransformationMethod(PasswordTransformationMethod.getInstance());
                } else
                {
                passwordEditText.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                }
            }
        });

//DB.First(); //Add first customer

        CheckBox remember=findViewById(R.id.remember);

        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);

            Email = mPreferences.getString("Email", Email);
      Remem = new int[]{mPreferences.getInt("Remember", 6)};
            Password = mPreferences.getString("Password", Password);
            if(Remem[0] ==1) {
                EmailEditText.setText(Email);
                passwordEditText.setText(Password);
                remember.setChecked(true);
            }
        TextView ForgetPassword=findViewById(R.id.forgetpassword);
            ForgetPassword.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    String Input;
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(LoginActivity.this);
                    alertDialogBuilder.setTitle("Forget Password");
                    EditText Emailedit=new EditText(getApplicationContext());
                    Emailedit.setText(Email);
                    EditText PasswordEdit=new EditText(getApplicationContext());
                    PasswordEdit.setHint("NewPassword...");
                    final String[] DefVal = {"Def"};
                    LinearLayout linearLayout=new LinearLayout(getApplicationContext());
                    linearLayout.setOrientation(LinearLayout.VERTICAL);
                    PasswordEdit.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    linearLayout.addView(Emailedit);
                    linearLayout.addView(PasswordEdit);
                    alertDialogBuilder
                            .setMessage("Enter Email & New Password ...")
                            .setCancelable(false).setView(linearLayout).setIcon(R.drawable.ic_baseline_person_24)
                            .setPositiveButton("Change", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    String NewPassword =PasswordEdit.getText().toString();
                                    DefVal[0]=NewPassword;
                                    //  Toast.makeText(getApplicationContext(), Address[0],Toast.LENGTH_SHORT).show();

                                    if (!DefVal[0].equals("Def")) {
                                        DefVal[0] ="Def";
                                        MyDatabaseClass Db=new MyDatabaseClass(getApplicationContext());
                                        Db.ChangePassord(Emailedit.getText().toString(),NewPassword);
                                        PasswordEdit.setText(NewPassword);
                                        Toast.makeText(getApplicationContext(), "Changed Successfully !",Toast.LENGTH_SHORT).show();

                                    }





                                    // Toast.makeText(oneHome.this, "Done", Toast.LENGTH_SHORT).show();

                                }
                            })
                            .setNegativeButton("CANCEL",new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    //  Toast.makeText(Admin.this, "CANCEL button click ", Toast.LENGTH_SHORT).show();

                                    dialog.cancel();
                                }
                            });

                    // create alert dialog
                    AlertDialog alertDialog = alertDialogBuilder.create();

                    // show it
                    alertDialog.show();







                }
            });
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //      loadingProgressBar.setVisibility(View.VISIBLE);
                 Email = EmailEditText.getText().toString();
                 Password = passwordEditText.getText().toString();
                SharedPreferences.Editor editor = getSharedPreferences(sharedPrefFile, MODE_PRIVATE).edit();
                editor.putString("Email", Email);
                editor.putString("Password",Password);
                if(remember.isChecked()) {
                    Remem[0] = 1;
                    editor.putInt("Remember", Remem[0]);
                }
                editor.apply();
                if (Email.equals("admin") && Password.equals("admin")) {
                    //Admin
                    Intent intent = new Intent(LoginActivity.this, Admin.class);
                    startActivity(intent);
                    finish();

                } else {
                    Cursor cursor = DB.userLogin(Email, Password);
                    if (cursor != null) {
                        if (cursor.getCount() <= 0) {
                            //Register

                            Intent intent = new Intent(LoginActivity.this, Register.class);
                            intent.putExtra("Email", Email);
                            intent.putExtra("Password", Password);
                            startActivity(intent);
                            //   finish();
                        } else {
                            Intent intent = new Intent(LoginActivity.this, oneHome.class);
                            intent.putExtra("Email", Email);
                            intent.putExtra("Password", Password);

                            startActivity(intent);

                            finish();
                        }

                    }


                }
            }
        });
    }
    @Override
    protected void onResume() {
        super.onResume();
        if (animationDrawable != null && !animationDrawable.isRunning()) {
            // start the animation
            animationDrawable.start();
        }
    }
    @Override
    protected void onPause() {
        super.onPause();
        if (animationDrawable != null && animationDrawable.isRunning()) {
            // stop the animation
            animationDrawable.stop();
        }

        SharedPreferences.Editor preferencesEditor =mPreferences.edit();
        preferencesEditor.putString("Email", Email);
        preferencesEditor.putString("Password", Password);
        preferencesEditor.putInt("Remember",Remem[0]);
        preferencesEditor.apply();

    }



    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }
}